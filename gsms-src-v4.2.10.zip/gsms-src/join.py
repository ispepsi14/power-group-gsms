#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ประกอบ HTML / CSS / JS กลับเป็น index.html ไฟล์เดียวที่เอาขึ้นเว็บได้

ตรวจ SHA-256 ให้ด้วย ถ้ายังไม่ได้แก้อะไรเลย ต้องได้ค่าเดิมเป๊ะ
ถ้าแก้แล้ว ค่าจะต่าง ซึ่งถูกต้อง แต่จะบอกให้เห็นว่าต่างจริง

ใช้:  python3 join.py <โฟลเดอร์ src> <ไฟล์ผลลัพธ์>
"""
import sys, os, json, hashlib

SRCDIR, OUTFILE = sys.argv[1], sys.argv[2]

meta = json.load(open(os.path.join(SRCDIR, 'parts.json'), encoding='utf-8'))
glue = meta['glue']
parts = meta['parts']

if len(glue) != len(parts) + 1:
    raise SystemExit('parts.json เสียหาย: จำนวนรอยต่อไม่ตรงกับจำนวนชิ้นส่วน')

out = []
out.extend(glue[0])
for i, p in enumerate(parts):
    path = os.path.join(SRCDIR, p['file'])
    if not os.path.exists(path):
        raise SystemExit('ขาดไฟล์: %s' % p['file'])
    body = open(path, encoding='utf-8', newline='').read()
    out.extend(body.split('\n'))
    out.extend(glue[i + 1])

text = '\n'.join(out)
data = text.encode('utf-8')

with open(OUTFILE, 'wb') as f:
    f.write(data)

new_sha = hashlib.sha256(data).hexdigest()
ref_sha = meta['source_sha256']

print('เขียนแล้ว : %s' % OUTFILE)
print('ขนาด      : %s ไบต์  (%d บรรทัด)' % (format(len(data), ','), text.count('\n') + 1))
crlf = data.count(b'\r\n')
print('ตัวจบบรรทัด CRLF : %s บรรทัด' % format(crlf, ','))
print()
print('SHA-256 ที่ได้  : %s' % new_sha)
print('SHA-256 ต้นฉบับ : %s' % ref_sha)
print()
if new_sha == ref_sha:
    print('ตรงกันทุกไบต์ — ยังไม่มีอะไรถูกแก้ ประกอบกลับได้ถูกต้อง')
    sys.exit(0)
print('ต่างจากต้นฉบับ — ถูกต้องถ้าคุณแก้โค้ดไปแล้ว')
print('ถ้ายังไม่ได้แก้อะไรเลยแต่ค่าต่าง = มีอะไรไปแตะไฟล์ (ส่วนมากคือตัวจัดรูปแบบอัตโนมัติ)')
sys.exit(0)
