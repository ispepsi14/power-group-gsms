"""ตรวจว่าฉบับแยกไฟล์ทำงานเหมือนไฟล์เดียวจริง

เทียบของจริงสองอย่าง:
  A. รายชื่อฟังก์ชัน/ตัวแปร global ที่แอปสร้างขึ้น ต้องเท่ากันเป๊ะ
  B. CSS ที่เบราว์เซอร์โหลดได้ ต้องได้จำนวนกฎเท่ากัน
  C. ต้องไม่มี JavaScript error ทั้งสองฉบับ
"""
import sys, pathlib, json
from playwright.sync_api import sync_playwright

SINGLE = pathlib.Path(sys.argv[1]).resolve()
SPLIT  = pathlib.Path(sys.argv[2]).resolve()

PROBE = r"""()=>{
  const names = Object.getOwnPropertyNames(window).filter(k => {
    try { return typeof window[k] === 'function' || k === k.toUpperCase(); }
    catch(e){ return false; }
  });
  let rules = 0, sheets = 0;
  for(const s of document.styleSheets){
    sheets++;
    // file:// ที่ลิงก์มาจากไฟล์นอก Chromium ห้ามอ่าน cssRules (SecurityError)
    // จึงไม่ใช้ตัวเลขนี้ตัดสิน ใช้ค่าที่คำนวณได้จริงบนหน้าจอแทน
    try { rules += s.cssRules.length; } catch(e){}
  }
  // วัดว่า CSS "ทำงานจริง" ไหม จากค่าที่เบราว์เซอร์คำนวณให้ element จริง
  const sp = document.getElementById('gsms-splash');
  const cs = sp ? getComputedStyle(sp) : null;
  const root = getComputedStyle(document.documentElement);
  const applied = cs ? {
    pos:   cs.position,
    bg:    cs.backgroundColor,
    zidx:  cs.zIndex,
    disp:  cs.display,
    align: cs.alignItems
  } : null;
  // ตัวแปรสีของธีม อยู่ใน styles.css ถ้าโหลดไม่ติดจะได้ค่าว่าง
  const tokens = ['--bg','--fg','--card','--line','--accent','--brand','--ink','--surface']
    .map(k => k + '=' + root.getPropertyValue(k).trim()).filter(s => !s.endsWith('='));
  return {
    applied: applied,
    tokens: tokens,
    fns: names.filter(k => { try { return typeof window[k] === 'function'; } catch(e){ return false; } }).sort(),
    appVersion: (typeof APP_VERSION !== 'undefined') ? APP_VERSION : null,
    hasConfig: (typeof FIREBASE_CONFIG !== 'undefined') && !!FIREBASE_CONFIG.projectId,
    sheets: sheets,
    rules: rules,
    splashOnScreen: !!document.getElementById('gsms-splash'),
    appDiv: !!document.getElementById('app')
  };
}"""

def probe(pg, path):
    errs = []
    pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto('file://' + str(path))
    pg.wait_for_timeout(2500)
    return pg.evaluate(PROBE), errs

with sync_playwright() as p:
    b = p.chromium.launch(executable_path='/opt/pw-browsers/chromium-1194/chrome-linux/chrome',
                          args=['--no-sandbox'])
    a_res, a_err = probe(b.new_page(viewport={'width':1280,'height':900}), SINGLE)
    b_res, b_err = probe(b.new_page(viewport={'width':1280,'height':900}), SPLIT)
    b.close()

ok = True
def check(name, cond, note=''):
    global ok
    if not cond: ok = False
    print(('  PASS  ' if cond else '  FAIL  ') + name + (('   — ' + note) if note else ''))

print('ไฟล์เดียว : %s' % SINGLE.name)
print('แยกไฟล์   : %s' % SPLIT.name)
print()

check('A-1 APP_VERSION ตรงกัน',
      a_res['appVersion'] == b_res['appVersion'] and a_res['appVersion'],
      '%s vs %s' % (a_res['appVersion'], b_res['appVersion']))
check('A-2 FIREBASE_CONFIG โหลดได้ทั้งสองฉบับ',
      a_res['hasConfig'] and b_res['hasConfig'])

only_single = sorted(set(a_res['fns']) - set(b_res['fns']))
only_split  = sorted(set(b_res['fns']) - set(a_res['fns']))
check('A-3 ฟังก์ชัน global เท่ากันเป๊ะ (%d ตัว)' % len(a_res['fns']),
      not only_single and not only_split,
      ('ขาดในฉบับแยก: ' + ', '.join(only_single[:8]) if only_single else '') +
      ('  เกินในฉบับแยก: ' + ', '.join(only_split[:8]) if only_split else ''))

check('B-1 จำนวน stylesheet ที่ติดมา',
      a_res['sheets'] > 0 and b_res['sheets'] > 0,
      '%d vs %d' % (a_res['sheets'], b_res['sheets']))
check('B-2 CSS ทำงานจริงบนหน้าจอ (ค่าที่เบราว์เซอร์คำนวณให้ #gsms-splash)',
      a_res['applied'] is not None and a_res['applied'] == b_res['applied'],
      json.dumps(a_res['applied'], ensure_ascii=False) + '  vs  ' +
      json.dumps(b_res['applied'], ensure_ascii=False))
check('B-3 ตัวแปรสีของธีมมาครบเท่ากัน',
      a_res['tokens'] == b_res['tokens'] and len(a_res['tokens']) > 0,
      '%d ตัว vs %d ตัว' % (len(a_res['tokens']), len(b_res['tokens'])))

check('C-1 หน้าโหลดและกล่อง #app มีอยู่',
      a_res['splashOnScreen'] and b_res['splashOnScreen'] and a_res['appDiv'] and b_res['appDiv'])
check('C-2 ไม่มี JavaScript error ในฉบับไฟล์เดียว', len(a_err) == 0, a_err[0][:100] if a_err else '')
check('C-3 ไม่มี JavaScript error ในฉบับแยกไฟล์', len(b_err) == 0, b_err[0][:100] if b_err else '')

print()
print('ฟังก์ชัน global ที่นับได้: %d ตัว' % len(a_res['fns']))
print('ตัวแปรสีของธีม: ' + ', '.join(a_res['tokens']))
print()
print('สรุป: ' + ('ฉบับแยกไฟล์ทำงานเหมือนไฟล์เดียว' if ok else 'ยังไม่เหมือน — ดูบรรทัด FAIL'))
sys.exit(0 if ok else 1)
