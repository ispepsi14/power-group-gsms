@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

rem ===================================================================
rem  POWER GROUP GSMS - ประกอบ src\ กลับเป็น index.html ไฟล์เดียว
rem
rem  แก้โค้ดที่  src\styles.css  src\app.js  ฯลฯ
rem  แล้วดับเบิลคลิกไฟล์นี้  มันจะเขียนทับ  ..\public\index.html
rem  (สำรองของเดิมไว้เป็น index.html.bak ให้ก่อนทุกครั้ง)
rem ===================================================================

echo.
echo ===================================================================
echo   ประกอบ index.html ไฟล์เดียว
echo ===================================================================
echo.

where python >nul 2>nul
if errorlevel 1 (
  echo [ERROR] ไม่พบ python
  echo         ติดตั้งจาก https://www.python.org/downloads/
  echo         ตอนติดตั้งต้องติ๊ก  Add python.exe to PATH
  echo.
  pause
  exit /b 1
)

if not exist "src\parts.json" (
  echo [ERROR] ไม่พบ src\parts.json
  echo         ต้องอยู่ในโฟลเดอร์ gsms-src ที่แตกมาทั้งก้อน
  echo.
  pause
  exit /b 1
)

set TARGET=..\public\index.html
if not exist "..\public" (
  echo [WARN]  ไม่พบโฟลเดอร์ ..\public  จะเขียนลง build\index.html แทน
  if not exist "build" mkdir "build"
  set TARGET=build\index.html
) else (
  if exist "%TARGET%" (
    copy /y "%TARGET%" "..\public\index.html.bak" >nul
    echo [OK]    สำรองของเดิมเป็น public\index.html.bak
  )
)

echo.
python join.py src "%TARGET%"
if errorlevel 1 (
  echo.
  echo [ERROR] ประกอบไม่สำเร็จ  ไฟล์เดิมยังอยู่
  echo.
  pause
  exit /b 1
)

echo.
echo [OK]    เขียนลง %TARGET% แล้ว
echo.
echo   อย่าลืม
echo     - bump APP_VERSION ใน src\config.js
echo     - แก้ public\version.json ให้เลขตรงกัน
echo     - แล้วค่อย push
echo.
pause
