#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
แยก index.html ไฟล์เดียวของ POWER GROUP GSMS ออกเป็น HTML / CSS / JS

เขียน "รอยต่อ" (แท็ก <style> <script> และบรรทัดว่าง) ลง parts.json ด้วย
เพราะฉะนั้น join.py ประกอบกลับได้เหมือนเดิมทุกไบต์ ไม่ต้องเดา

ใช้:  python3 split.py <ทางเดินของ index.html> <โฟลเดอร์ปลายทาง>
"""
import sys, os, hashlib, json

SRC, OUT = sys.argv[1], sys.argv[2]

raw = open(SRC, 'rb').read()
orig_sha = hashlib.sha256(raw).hexdigest()
lines = raw.decode('utf-8').split('\n')   # ยังมี \r ท้ายบรรทัด (ไฟล์เป็น CRLF)

def find_exact(token, start=0):
    for i in range(start, len(lines)):
        if lines[i].rstrip('\r') == token:
            return i + 1
    raise SystemExit('หาไม่เจอ: %r' % token)

cfg_open   = find_exact('<script>')
cfg_close  = find_exact('</script>', cfg_open)
css1_open  = find_exact('<style>',  cfg_close)
css1_close = find_exact('</style>', css1_open)
css2_open  = find_exact('<style>',  css1_close)
css2_close = find_exact('</style>', css2_open)
head_close = find_exact('</head>',  css2_close)

# สคริปต์หลัก = บรรทัดที่เป็น <script> / </script> เป๊ะ ๆ ตัวสุดท้ายของไฟล์
app_open = app_close = None
for i, ln in enumerate(lines):
    s = ln.rstrip('\r')
    if s == '<script>':  app_open = i + 1
    if s == '</script>': app_close = i + 1
body_close = find_exact('</body>', app_close)
html_close = find_exact('</html>', body_close)

# ลำดับชิ้นส่วน (ชื่อไฟล์, บรรทัดเริ่ม, บรรทัดจบ)
PARTS = [
    ('01-head.html',      1,              cfg_open - 1),
    ('config.js',         cfg_open + 1,   cfg_close - 1),
    ('changelog.html',    cfg_close + 1,  css1_open - 1),
    ('styles.css',        css1_open + 1,  css1_close - 1),
    ('styles-splash.css', css2_open + 1,  css2_close - 1),
    ('02-body.html',      head_close,     app_open - 1),
    ('app.js',            app_open + 1,   app_close - 1),
    ('03-tail.html',      body_close,     html_close),
]

os.makedirs(OUT, exist_ok=True)

# ---- รอยต่อ: บรรทัดที่อยู่ "ระหว่าง" ชิ้นส่วน เก็บไว้ดิบ ๆ ----
glue = []
glue.append(lines[0:PARTS[0][1]-1])                      # ก่อนชิ้นแรก (ว่าง)
for k in range(len(PARTS) - 1):
    glue.append(lines[PARTS[k][2] : PARTS[k+1][1]-1])
glue.append(lines[PARTS[-1][2]:])                        # หลังชิ้นสุดท้าย

manifest = []
for name, a, b in PARTS:
    body = '\n'.join(lines[a-1:b])
    with open(os.path.join(OUT, name), 'w', encoding='utf-8', newline='') as f:
        f.write(body)
    manifest.append({'file': name, 'from': a, 'to': b,
                     'lines': b - a + 1, 'bytes': len(body.encode('utf-8'))})

with open(os.path.join(OUT, 'parts.json'), 'w', encoding='utf-8', newline='\n') as f:
    json.dump({'source': os.path.basename(SRC),
               'source_sha256': orig_sha,
               'total_lines': len(lines),
               'parts': manifest,
               'glue': glue}, f, ensure_ascii=False, indent=2)

print('ต้นทาง   : %s' % SRC)
print('SHA-256  : %s' % orig_sha)
print()
print('%-22s %8s %12s   %s' % ('ไฟล์', 'บรรทัด', 'ไบต์', 'ช่วงในไฟล์เดิม'))
print('-' * 66)
for m in manifest:
    print('%-22s %8d %12s   %d-%d' % (m['file'], m['lines'], format(m['bytes'], ','), m['from'], m['to']))
print('-' * 66)
print('%-22s %8d %12s' % ('รวม', sum(m['lines'] for m in manifest),
                          format(sum(m['bytes'] for m in manifest), ',')))
print('รอยต่อที่เก็บไว้ : %d บรรทัด' % sum(len(g) for g in glue))
