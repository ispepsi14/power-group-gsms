  // These keys are NOT secret — every Firebase web app ships them in the page.
  // Access is controlled by Firestore Security Rules + user accounts, not by hiding this.
  const FIREBASE_CONFIG = {
    apiKey: "AIzaSyDaZS0zuG4AcC5d0-BE2AJIRtmjh8bfrzE",
    authDomain: "power-group-gsms.firebaseapp.com",
    projectId: "power-group-gsms",
    storageBucket: "power-group-gsms.firebasestorage.app",
    messagingSenderId: "794612913632",
    appId: "1:794612913632:web:8412ee1e11ec3a46e90785"
  };
  // Bootstrap admin: this account is treated as admin even before the users/{uid}
  // document exists, so the very first login can create everyone else.
  const BOOTSTRAP_ADMIN_UID = "79YAV3SBT7ZAFfCz9rLMYyTRlPw1";

  // Shown in the app bar + Settings. Bump this on every change so it is obvious at a
  // glance whether a device is actually running the newest deploy or a cached copy.
  const APP_VERSION = "4.2.10";